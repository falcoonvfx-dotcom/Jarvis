# J.A.R.V.I.S. - Groq + Fish Audio voice assistant (PWA)

Browser app (Android Chrome) + small Node backend. API keys live ONLY on the server as environment variables.

## Run locally (computer)
1. Install Node 18+.
2. `npm install`
3. `cp .env.example .env` and put your keys in `.env` (this file is git-ignored).
4. `npm start` -> open http://localhost:3000

## Deploy from your Android phone (free, HTTPS - required for the microphone)
1. Create a GitHub repo and upload this folder (**do not upload a `.env` file**; only `.env.example`).
2. On https://render.com (or Railway / Koyeb) choose **New > Web Service**, connect the repo.
   - Build command: `npm install`   Start command: `npm start`
3. Open **Environment** and add variables (the values never touch your code):
   - `GROQ_API_KEY` = your Groq key
   - `FISH_API_KEY` = your Fish Audio key
   - `ACCESS_CODE` = any secret phrase (recommended, stops strangers using your keys)
   - optional: `FISH_VOICE_ID`, `GROQ_MODEL`, `FISH_MODEL`
4. Deploy, open the URL in **Chrome on Android**, allow Microphone, enter your access code in Settings.
5. Chrome menu (⋮) > **Install app** / Add to Home screen.

## Using it
Tap 🎤 and speak; or type. 🔊 toggles voice, ⏹ stops speech, ⚙ = voice ID, title, language, clear chat.
Find voice IDs in the Fish Audio voice library (the ID is in the voice's URL).

## Notes
- Mic speech-to-text uses Chrome's built-in recognizer (needs HTTPS + internet).
- Browsers cannot read real CPU/RAM load; the HUD shows cores, device memory, network latency and battery.
- Fish default model is `s2.1-pro-free`; change with `FISH_MODEL` if you have credit (e.g. `s2-pro`).
- If a key was ever pasted in a chat or committed, **rotate it** in the provider dashboard.
